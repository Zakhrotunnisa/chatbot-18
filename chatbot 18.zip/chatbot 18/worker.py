import os
import cv2
from langchain import OpenAI
from langchain.chains import ConversationalRetrievalChain
from langchain.embeddings import OpenAIEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.vectorstores import Chroma
from dotenv import load_dotenv
import pytesseract
from PIL import Image
import requests
import numpy as np
from io import BytesIO
from transformers import pipeline

# Load environment variables
load_dotenv()

# Initialize global variables
conversation_retrieval_chain = None
chat_history = []
llm = None
llm_embeddings = None

# Initialize the image classifier
image_classifier = pipeline("image-classification", "umm-maybe/AI-image-detector")

# Function to initialize the language model and its embeddings
def init_llm():
    global llm, llm_embeddings
    # Initialize the language model with the OpenAI API key
    api_key = os.getenv("sk-proj-la4NaINYYzP8NUm6Cpq8T3BlbkFJvvPJP9gvurmtK0BhDSUo")
    llm = OpenAI(model_name="gpt-3.5-turbo", openai_api_key=api_key)
    # Initialize the embeddings for the language model
    llm_embeddings = OpenAIEmbeddings(openai_api_key=api_key)

# Function to process an image document
def process_image(image_path):
    global conversation_retrieval_chain, llm, llm_embeddings
    if llm is None:
        init_llm()  # Make sure the language model is initialized before processing the image
    
    # Load the image
    image = cv2.imread(image_path)
    # Convert image to text using OCR (Optical Character Recognition)
    text = pytesseract.image_to_string(image)
    # Split the extracted text into chunks
    text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
    texts = text_splitter.split_text(text)  # Correct the method name to split_text
    # Create a vector store from the text chunks
    db = Chroma.from_texts(texts, llm_embeddings)
    # Create a retriever interface from the vector store
    retriever = db.as_retriever(search_type="similarity", search_kwargs={"k": 2})
    # Create a conversational retrieval chain from the language model and the retriever
    conversation_retrieval_chain = ConversationalRetrievalChain.from_llm(llm, retriever)

# Function to process a user prompt
def process_prompt(prompt):
    global conversation_retrieval_chain
    global chat_history
    if conversation_retrieval_chain is None:
        return "Please upload a document first."  # Inform the user to upload a document first
    
    # Generate a response to the user's prompt
    result = conversation_retrieval_chain({"question": prompt, "chat_history": chat_history})
    # Update the chat history
    chat_history.append((prompt, result["answer"]))
    # Return the model's response
    return result['answer']

# Function to process an image using AI image detector
def process_image_ai(image_url):
    response = requests.get(image_url)
    image = Image.open(BytesIO(response.content))
    image_np = np.array(image)
    results = image_classifier(image_np)
    return results

# Initialize the language model
init_llm()
